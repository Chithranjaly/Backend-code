package project.anhBackend.service;

import org.springframework.web.multipart.MultipartFile;
import project.anhBackend.dto.CourseDto;

import java.util.List;

public interface CourseService {
    CourseDto saveCourse(CourseDto courseDto,MultipartFile courseImage,String username);
    List<CourseDto> getAllCourses();
}
