package project.anhBackend.controller;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import project.anhBackend.dto.CourseDto;
import project.anhBackend.entity.Courses;
import project.anhBackend.service.CourseService;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/api/courses")
@CrossOrigin("*")
public class CourseController {

    private CourseService courseService;

    @PostMapping
    public ResponseEntity<CourseDto> addCourse(@ModelAttribute CourseDto courseDto,
                                               @RequestParam("courseImage") MultipartFile courseImage,
                                               @RequestParam("username") String username){
        CourseDto createdCourse=courseService.saveCourse(courseDto,courseImage,username);
        return new ResponseEntity<>(createdCourse,HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<CourseDto>> getAllCourses() {
        List<CourseDto> courses = courseService.getAllCourses();
        return new ResponseEntity<>(courses, HttpStatus.OK);
    }
}
