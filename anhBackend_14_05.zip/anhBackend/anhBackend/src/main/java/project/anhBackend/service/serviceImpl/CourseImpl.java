package project.anhBackend.service.serviceImpl;

import lombok.AllArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;
import project.anhBackend.dto.CourseDto;
import project.anhBackend.entity.Courses;
import project.anhBackend.entity.Instructor;
import project.anhBackend.repository.CourseRepo;
import project.anhBackend.repository.InstructorRepo;
import project.anhBackend.service.CourseService;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class CourseImpl implements CourseService {

    private CourseRepo courseRepo;
    private InstructorRepo instructorRepo;
    private final String uploadDir;
    private ModelMapper modelMapper;

    @Autowired
    public CourseImpl(CourseRepo courseRepo,InstructorRepo instructorRepo,ModelMapper modelMapper, @Value("${product.image.upload-dir}") String uploadDir){
        this.courseRepo=courseRepo;
        this.instructorRepo=instructorRepo;
        this.uploadDir=uploadDir;
        this.modelMapper=modelMapper;
    }

    @Override
    public CourseDto saveCourse(CourseDto courseDto,MultipartFile courseImage,String username) {
        Instructor instructor=instructorRepo.findByUsername(username);
        if (courseImage != null && !courseImage.isEmpty()) {
            try {
                // Get the file name
                String fileName = StringUtils.cleanPath(courseImage.getOriginalFilename());
                // Set the file path where the image will be stored
                Path uploadPath = Paths.get(uploadDir + fileName);

                Path directory = uploadPath.getParent();
                if (!Files.exists(directory)) {
                    Files.createDirectories(directory);
                }

                // Copy the file to the upload path
                Files.copy(courseImage.getInputStream(), uploadPath, StandardCopyOption.REPLACE_EXISTING);
                // Set the profile picture URL in the DTO
                courseDto.setPicUrl(uploadPath.toString());
            } catch (IOException e) {
                e.printStackTrace(); // Handle the exception appropriately
            }
        }
        courseDto.setStatus("Pending");
        courseDto.setInstructorId(instructor.getId());
        Courses courses=modelMapper.map(courseDto,Courses.class);

        Courses savedCourse=courseRepo.save(courses);

        return modelMapper.map(savedCourse,CourseDto.class);
    }

    @Override
    public List<CourseDto> getAllCourses() {
        return courseRepo.findAll().stream()
                .map(course -> modelMapper.map(course, CourseDto.class))
                .collect(Collectors.toList());
    }
}
