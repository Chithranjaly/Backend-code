package project.anhBackend.config;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class JacksonConfig {

        @Bean
        public ObjectMapper objectMapper() {
            ObjectMapper objectMapper = new ObjectMapper();
            // Register the custom module to ignore Hibernate proxy properties during serialization
            objectMapper.registerModule(new HibernateProxyModule());
            return objectMapper;
        }

        // Custom Jackson module to ignore Hibernate proxy properties during serialization
        public static class HibernateProxyModule extends SimpleModule {
            public HibernateProxyModule() {
                setMixInAnnotation(Object.class, HibernateProxyMixin.class);
            }
        }

        // Mix-in class to ignore Hibernate proxy properties
        public abstract static class HibernateProxyMixin {
        }
}
