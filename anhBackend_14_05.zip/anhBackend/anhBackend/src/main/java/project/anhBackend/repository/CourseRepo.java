package project.anhBackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import project.anhBackend.entity.Courses;

public interface CourseRepo extends JpaRepository<Courses,Long> {
}
