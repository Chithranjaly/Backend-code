package project.anhBackend.service;

import project.anhBackend.dto.DepartmentDto;
import project.anhBackend.dto.StudentDto;

import java.util.List;

public interface StudentService {

    StudentDto RegisterStudent(StudentDto studentDto);
    StudentDto getStudentById(Long studentId);
    List<StudentDto> getAllStudents();
    StudentDto updateStudent(Long studentId, StudentDto updatedStudent);
    void deleteStudent(Long studentId);
}
