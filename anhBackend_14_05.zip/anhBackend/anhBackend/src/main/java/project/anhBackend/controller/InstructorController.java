package project.anhBackend.controller;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import project.anhBackend.dto.GetInstructorDto;
import project.anhBackend.dto.InstructorDto;
import project.anhBackend.service.InstructorService;

import java.util.List;

@RestController
@AllArgsConstructor
@CrossOrigin("*")
@RequestMapping("/api/instructors")
public class InstructorController {

    private InstructorService instructorService;

    @PostMapping
    public ResponseEntity<InstructorDto> addInstructor(@RequestBody InstructorDto instructorDto){
        InstructorDto instructor=instructorService.addInstructor(instructorDto);
        return new ResponseEntity<>(instructor, HttpStatus.CREATED);
    }

    @GetMapping("{id}")
    public ResponseEntity<InstructorDto> getInstructorById(@PathVariable("id") Long instructorId){
        InstructorDto instructor=instructorService.getInstructorById(instructorId);
        return ResponseEntity.ok(instructor);
    }

    @GetMapping
    public ResponseEntity<List<InstructorDto>> getAllInstructors(){
    List<InstructorDto> instructorDtos=instructorService.getAllInstructors();
    return ResponseEntity.ok(instructorDtos);
    }

    @PutMapping("{id}")
    public ResponseEntity<InstructorDto> updateInstructor(@PathVariable("id") Long instructorId,
                                                          @RequestBody InstructorDto instructorDto){
        InstructorDto savedInstructor=instructorService.updateInstructor(instructorId,instructorDto);
        return ResponseEntity.ok(savedInstructor);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<String> deleteInstructor(@PathVariable("id") Long instructorId){
        instructorService.deleteInstructor(instructorId);
        return ResponseEntity.ok("Deleted successfully");
    }

    @GetMapping("/custom")
    public ResponseEntity<List<GetInstructorDto>> getAll(){
        List<GetInstructorDto> instructorDtos=instructorService.getAll();
        return ResponseEntity.ok(instructorDtos);
    }

    @GetMapping("profile/{username}")
    public ResponseEntity<InstructorDto> getByUsername(@PathVariable("username") String usename){
        InstructorDto instructorDto=instructorService.getInstructorByUsername(usename);
        return ResponseEntity.ok(instructorDto);
    }


}
