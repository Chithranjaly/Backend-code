package project.anhBackend.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class StudentDto {
    private Long id;
    private String f_name;
    private String l_name;
    private Long age;
    private String phone;
    private String email;
    private String username;
    private String password;

}
