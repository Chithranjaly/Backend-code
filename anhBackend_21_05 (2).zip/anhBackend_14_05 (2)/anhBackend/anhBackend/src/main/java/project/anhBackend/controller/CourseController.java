package project.anhBackend.controller;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import project.anhBackend.dto.CourseDto;
import project.anhBackend.entity.Courses;
import project.anhBackend.service.CourseService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@AllArgsConstructor
@RequestMapping("/api/courses")
@CrossOrigin("*")
public class CourseController {

    private CourseService courseService;

    @PostMapping
    public ResponseEntity<CourseDto> addCourse(@ModelAttribute CourseDto courseDto,
                                               @RequestParam("courseImage") MultipartFile courseImage,
                                               @RequestParam("username") String username){
        CourseDto createdCourse=courseService.saveCourse(courseDto,courseImage,username);
        return new ResponseEntity<>(createdCourse,HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<CourseDto>> getAllCourses() {
        List<CourseDto> courses = courseService.getAllCourses();
        return new ResponseEntity<>(courses, HttpStatus.OK);
    }

    @GetMapping("/custom/{id}")
    public ResponseEntity<List<CourseDto>> getCourseByInstructorId(@PathVariable("id") Long instructorId){
        List<Courses> courses = courseService.getCoursesByInstructorId(instructorId);
        List<CourseDto> courseDtos = courses.stream()
                .map(course -> new CourseDto(
                        course.getId(),
                        course.getCourse_name(),
                        course.getCourse_description(),
                        course.getPrice(),
                        course.getStatus(),
                        course.getPicUrl(),
                        course.getInstructor().getId()))
                .collect(Collectors.toList());
        return new ResponseEntity<>(courseDtos, HttpStatus.OK);
    }

    @PatchMapping("/approve/{id}")
    public ResponseEntity<CourseDto> approveCourse(@PathVariable("id") Long id){
        CourseDto courseDto=courseService.approve(id);
        return new ResponseEntity<>(courseDto, HttpStatus.OK);
    }


    @PatchMapping("/reject/{id}")
    public ResponseEntity<CourseDto> rejectCourse(@PathVariable("id") Long id){
        CourseDto courseDto=courseService.reject(id);
        return new ResponseEntity<>(courseDto, HttpStatus.OK);
    }
}
