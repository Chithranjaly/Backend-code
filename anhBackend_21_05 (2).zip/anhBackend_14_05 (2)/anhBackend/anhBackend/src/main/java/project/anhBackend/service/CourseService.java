package project.anhBackend.service;

import org.springframework.web.multipart.MultipartFile;
import project.anhBackend.dto.CourseDto;
import project.anhBackend.entity.Courses;

import java.util.List;

public interface CourseService {
    CourseDto saveCourse(CourseDto courseDto,MultipartFile courseImage,String username);
    List<CourseDto> getAllCourses();
    List<Courses> getCoursesByInstructorId(Long instructorId);
    CourseDto approve(Long id);
    CourseDto reject(Long id);
}
