package project.anhBackend.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import project.anhBackend.entity.Courses;

import java.util.List;

public interface CourseRepo extends JpaRepository<Courses,Long> {

    @Query("SELECT c FROM Courses c WHERE c.instructor.id = :instructorId")
    List<Courses> findCoursesByInstructorId(@Param("instructorId") Long instructorId);

}
