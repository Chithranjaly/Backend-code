package project.anhBackend.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class CourseDto {
    private Long id;
    private String course_name;
    private String course_description;
    private Long price;
    private String status;
    private String picUrl;
    private Long instructorId;
}
